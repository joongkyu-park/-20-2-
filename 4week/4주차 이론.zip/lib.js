/* �ڹٽ�ũ��Ʈ ���� lib.js */
function over(obj) {
	obj.src="https://healthtips.co.kr/wp-content/uploads/2018/11/%EB%B0%94%EB%82%98%EB%82%98-%EC%B9%BC%EB%A1%9C%EB%A6%AC.jpg";
}
function out(obj) {
	obj.src="https://lh3.googleusercontent.com/proxy/l7wi7G-Kwzgw11Jwijv0uHFFf7Tj3QggGw8mmunwobqq3MzHUNsY1aYpFcMspzZN_uHrmfwVlL7z3e4veAdQNb_mLVBc8zVlXcORe_Fnr_AyCYHX4r1TlIeTLbLxeaCyCp8CJAcZOSAY1E0c45THe3xwjAuPVER73JBhG3IGk5vDAsl5svqUE6F5t-2eiuIzZAG4TyyjWu0czXIM2oB_XLcysagEFfVaUvY9Av3gnRwKNuMQ-n3tDfweEaf788MvU9vYDfkenuccxeQ3pOKlTyZlVEL4Yxm92MBG7_9HTM6XqufrgKXKBy1zECw";
}
